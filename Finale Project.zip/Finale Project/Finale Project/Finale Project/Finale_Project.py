# Ali Ibrahim
# Final Project
# Requirments:
#•	Multiple customer accounts can be created. 
#•	The accounts can be either savings or checking
#•	The accounts are set up by customer first name, last name, and SSN
#•	The savings account has a minimum deposit of $500.00.  
#•	The accounts can be added to or deducted from for any customer. 
#•	The savings account cannot go below the minimum deposit. 
#•	If checking goes below the balance of 0, a fee of $20.00 is applied per transaction. 
#•	All deposits to any account must be numeric and above 0.  
#•	All deductions from any account must be numeric and above 0. 
#•	At any time, the balance for checking and savings can be displayed per customer. 
#•	At any time, the total balance for all accounts per customer can be viewed. 
#•	The customer can have multiple checking and multiple savings accounts. 
########################################################################################
# Customer Class 
class customers:
    def __init__(self, firstname, lastname, ssn):
        # Validate the data from customer information 
             try:
                if (firstname.isnumeric())==False:
                    self.firstname = firstname
             except Exception:
                print("First Name Must be Letters")
        
             try:
                if (lastname.isnumeric())==False:
                   self.lastname = lastname
             except Exception:
                 print("Last Name Must be Letters")  
        
             try:
                self.ssn=int(ssn)
             except ValueError:
               print("SSN Must be a Number") 
        
# account class        
class account(customers):
    #multiple accounts for both saving and checking
    def __init__(self, firstname, lastname, ssn, dblsaving =500, dblchecking=0, dblsavingsecond=500, dblcheckingsecond=0):
       customers.__init__(self, firstname, lastname, ssn)
       #validate accounts and validate saving is above minimum deposit of 500
       if dblsaving <500:
           print("Saving account is below the minimum deposit of 500, try again")
       else:
           self.dblsaving = dblsaving

       if dblsavingsecond <500:
           print("The Second Saving account is below the minimum deposit of 500, try again")
       else:
           self.dblsavingsecond = dblsavingsecond
           
       try:
           self.dblchecking = int(dblchecking)
       except ValueError:
              print("Checking account must be a Number")
       try:
           self.dblcheckingsecond = int(dblcheckingsecond)
       except ValueError:
              print("The Second Checking account  must be a Number")
# List of customers and validating choice
    def choose():
        global dblsaving
        global dblchecking
        global dblsavingsecond
        global dblcheckingsecond
        print("Select Customer")
        print ("1. Ali Ibrahim")
        print ("2. Bob Rice")
        print ("3. Jack Daniels")
        print ("4. Max Horn")
        while True:
            try:
                choice = int(input("Enter choice (1/2/3/4)"))
                if choice != 1 and choice !=2 and choice !=3 and choice != 4:
                    print("Sorry input must be (1/2/3/4) only, try again")
                    continue
            except ValueError:
                print("Sorry input must be (1/2/3/4) only, try again")
                continue
            else:
                #Assign value of accounts per each customer
               if choice == 1:
                   
                   dblsaving = 500
                   dblsavingsecond = 600
                   dblchecking = 300
                   dblcheckingsecond = 900
                   account.checkbalance()
               
               elif choice == 2:
                   
                   
                   dblsaving = 600
                   dblsavingsecond = 700
                   dblchecking = 200
                   dblcheckingsecond = 1000
                   account.checkbalance()
               
               elif choice == 3:
                    
                    
                    dblsaving = 700
                    dblsavingsecond = 800
                    dblchecking =600
                    dblcheckingsecond = 300
                    account.checkbalance()
               
               elif choice == 4:
                    
                    dblsaving= 900
                    dblsavingsecond = 500
                    dblchecking= 200
                    dblcheckingsecond = 400
                    account.checkbalance()
 # allow the account balance to be displayed multiple times
 #validate choice
    def checkbalance():
        # give user a choice to not see balance and to keep going
        while True:
            try:
               balancedisplay=int(input("If you want to see the balance for your accounts press 1 to go to the next step press 2. (1/2) "))
               if balancedisplay !=1 and balancedisplay !=2:
                   print("Sorry, input must be 1 or 2 only, try again")
                   continue
               if balancedisplay ==1:
                  print("The Savings account balance for the selected customer is ", dblsaving)
                  print("The Second Savings account balance for the selected customer is ", dblsavingsecond)
                  print("The Checkings account balance for the selected customer is", dblchecking)
                  print("The Second Checkings account balance for the selected customer is", dblcheckingsecond)
                  account.ask()
                  #keep going 
               if balancedisplay ==2:
                  account.ask()
            except ValueError:
                   print("Input must be either 1 or 2, try again")
    # ask the user if they want to add or deduct from account
    #validate choice
    def ask():
        
        while True:
            try:

               addordeduct=int(input("Choose 1 to add money to your account , Choose 2 to deduct money from your account (1/2)"))
               if addordeduct != 1 and addordeduct !=2:
                   print("Sorry, input must be 1 or 2 only, try again")
                   continue
            except ValueError:
                  print("Input must be either 1 or 2 , try again")
                  continue
            else:
                  if addordeduct ==1:
                      account.add()
                      break
                  if addordeduct ==2:
                      account.deduct()
                      break
        #add to account              
    def add():
      global dblsaving
      global dblchecking
      while True:
             
             try:
                 addition= int(input("What is the amount you would like to add to your account?"))
                 if addition < 0:
                     print("Sorry, input must be a positive integer, try again")
                     continue
                 break
             except ValueError:
                 print("Amount must be a number")
                 continue
             else:
               return addition
      while True:
             # ask which account and validate choice
             try:
                 print("Select an Account")
                 print("1. Primary Savings")
                 print("2. Secondary Savings")
                 print("3. Primary Checkings")
                 print("4. Secondary Checkings")
                 accounttype= int(input("Please Enter which account you would like to add to (1/2/3/4)"))
                 if accounttype != 1 and accounttype !=2 and accounttype!=3 and accounttype!=4:
                     print("Sorry, input must be 1 or 2 only , try again")
                     continue
                 
             except ValueError:
                 print("Account must be either 1 or 2")
                 continue
             else:
                 if accounttype ==1:
                     
                     dblsaving = addition + dblsaving
                     print("Savings account balance is now ", dblsaving)
                     account.checkbalance()
                    
                 if accounttype ==3:
                     
                     dblchecking = addition + dblchecking
                     print("Checkings account balance is now ", dblchecking)
                     account.checkbalance()
                 if accounttype ==2:
                    dblsavingsecond = addition +dblsavingsecond
                    print("Secondary Savings account balance is now", dblsavingsecond)
                    account.checkbalance()
                 if accounttype ==4:
                     
                     dblcheckingsecondg = addition + dblcheckingsecondg
                     print("Secondary Checkings account balance is now ", dblcheckingsecondg)
                     account.checkbalance()
     #deduct function 
     #validate choice
     #validate data and parameters
    def deduct():
      global dblsaving
      global dblchecking
      while True:
             
             try:
                 deduction= int(input("What is the amount you would like to deduct to your account?"))
                 if deduction < 0:
                     print("Sorry, input must be a positive integer, try again")
                     continue
                 break
             except ValueError:
                 print("Amount must be a number")
                 continue
             else:
               return deduction
      while True:
             #ask which account 
             try:
                 print("Select an Account")
                 print("1. Primary Savings")
                 print("2. Secondary Savings")
                 print("3. Primary Checkings")
                 print("4. Secondary Checkings")
                 accounttype= int(input("Please Enter which account you would like to deduct to (1/2/3/4)"))
                 if accounttype != 1 and accounttype !=2 and accounttype!=3 and accounttype!=4:
                     print("Sorry, input must be 1 or 2 only , try again")
                     continue
                 
             except ValueError:
                 print("Account must be either 1 or 2")
                 continue
             else:
                 if accounttype ==1:
                     
                     
                     if dblsaving - deduction < 500:
                         
                         print("Savings account may not go below the minimum of 500, Your current  account balance is", dblsaving)
                         account.choose()
                     else:
                         dblsaving = dblsaving - deduction
                         print("Savings account balance is now ", dblsaving)
                         account.checkbalance()
                 if accounttype ==2:
                     
                     
                     if dblsavingsecond - deduction < 500:
                         
                         print("Secondary Savings account may not go below the minimum of 500, Your current account balance is", dblsavingsecond)
                         account.choose()
                     else:
                         dblsavingsecond = dblsavingsecond - deduction
                         print("Secondary Savings account balance is now ", dblsavingsecond)
                         account.checkbalance()
                    
                 if accounttype ==3:
                     
                     if dblchecking - deduction <= 0:
                         dblchecking = dblchecking - deduction
                         print("Checkings account balance is now ", str(dblchecking))
                         print("Your checking account is now below 0 and will be charged a fee of 20$ per transaction")
                         dblchecking = dblchecking - 20
                         account.checkbalance()
                     else:
                         dblchecking = dblchecking - deduction
                         print("Checkings account balance is now ", dblchecking)
                         account.checkbalance()
                 if accounttype ==4:
                     
                     if dblcheckingsecond - deduction <= 0:
                         dblcheckingsecond = dblcheckingsecond - deduction
                         print("Secondary Checkings account balance is now ", str(dblcheckingsecond))
                         print("Your Secondary Checking account is now below 0 and will be charged a fee of 20$ per transaction")
                         dblcheckingsecond = dblcheckingsecond - 20
                         account.checkbalance()
                     else:
                         dblcheckingsecond = dblcheckingsecond - deduction
                         print("Secondary Checkings account balance is now ", dblcheckingsecond)
                         account.checkbalance()
    
#list of customers          
cust_1 = account ('Ali', 'Ibrahim', 223443132)
cust_2 = account ('Bob', 'Rice', 331425678)
cust_3 = account ('Jack', 'Daniels', 123456789)
cust_4 = account ('Max', 'Horn', 987654321)



# call on first functions for user input
account.choose()
account.checkbalance()



